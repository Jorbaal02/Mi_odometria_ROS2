from setuptools import find_packages, setup

package_name = 'mi_odometria'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jorbaal',
    maintainer_email='jorbaal@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    entry_points={
        'console_scripts': [
            'leer_orientacion = mi_odometria.leer_orientacion:main',
            'controlar_orientacion = mi_odometria.control_orientacion:main',
            'Ejercicio_1 = mi_odometria.Ejercicio_1:main',
            'Ejercicio_2 = mi_odometria.Ejercicio_2:main',
            'Ejercicio_3 = mi_odometria.Ejercicio_3:main',
            'Ejercicio_4 = mi_odometria.Ejercicio_4:main',
            'Ejercicio_5 = mi_odometria.Ejercicio_5:main',
            'Ejercicio_6 = mi_odometria.Ejercicio_6:main',
            'Ejercicio_7 = mi_odometria.Ejercicio_7:main',
            'Ejercicio_8 = mi_odometria.Ejercicio_8:main',
        ],
    },
)

